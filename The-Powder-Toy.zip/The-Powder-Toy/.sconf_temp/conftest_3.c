#include <stdlib.h>
	#include <stdio.h>
	int main() {
		printf("%d", (int)sizeof(size_t));
		return 0;
	}
	