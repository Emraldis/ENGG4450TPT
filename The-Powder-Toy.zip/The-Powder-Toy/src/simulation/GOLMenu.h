#ifndef The_Powder_Toy_GOLMenu_h
#define The_Powder_Toy_GOLMenu_h

struct gol_menu
{
	const char *name;
	pixel colour;
	int goltype;
	const char *description;
};

#endif
