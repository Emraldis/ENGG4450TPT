#include "simulation/Element.h"
#include "ToolClasses.h"

SimTool::SimTool():
Identifier("DEFAULT_TOOL_INVALID"),
Name(""),
Colour(PIXPACK(0xFFFFFF)),
Description("NULL Tool, does NOTHING")
{
}
